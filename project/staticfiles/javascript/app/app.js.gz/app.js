(function() {
    'use strict';

    angular.module('AutomaticBD', ['ngRoute']);

    angular.element(document).ready(function() {
        angular.bootstrap(document.body, ['AutomaticBD']);
    });

})();
